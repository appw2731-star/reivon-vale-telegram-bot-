# Reivon Vale Telegram Portfolio Bot

এই প্রজেক্টটি Vercel-এ deploy করার জন্য তৈরি। Telegram bot-এ Website, App Design, Graphics ও Other Projects ক্যাটাগরি থাকবে। Admin হিসেবে শুধু `ADMIN_ID`-এ দেওয়া Telegram ID প্রজেক্ট যোগ/মুছতে পারবে।

## 1) GitHub repository তৈরি
1. GitHub-এ নতুন একটি repository তৈরি করো।
2. এই ZIP-এর ভেতরের সব ফাইল repository-তে upload করো।
3. `data/projects.json` ফাইলটি অবশ্যই থাকবে।

## 2) GitHub token তৈরি
GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens।
শুধু তোমার repository নির্বাচন করে **Contents: Read and write** permission দাও। Token কপি করে নিরাপদে রাখো।

## 3) Vercel deploy
1. Vercel-এ GitHub repository Import করো।
2. Framework Preset: Other রাখো।
3. Environment Variables-এ `.env.example`-এর প্রতিটি variable যোগ করো:
   - `BOT_TOKEN`: BotFather-এর token
   - `ADMIN_ID`: তোমার Telegram numeric ID
   - `GITHUB_REPO`: `username/repository`
   - `GITHUB_BRANCH`: `main` (অথবা তোমার default branch)
   - `GITHUB_FILE_PATH`: `data/projects.json`
   - `GITHUB_TOKEN`: আগের GitHub token
   - `WEBHOOK_SECRET`: নিজের বানানো দীর্ঘ random secret
   - `APP_URL`: Vercel deployment URL, যেমন `https://your-project.vercel.app`
4. Deploy করো।

## 4) Telegram webhook চালু
Deploy শেষ হলে browser-এ এই URL খোলো:

`https://YOUR-VERCEL-PROJECT.vercel.app/api/set-webhook?secret=YOUR_WEBHOOK_SECRET`

`YOUR-VERCEL-PROJECT` ও `YOUR_WEBHOOK_SECRET` নিজের মান দিয়ে বদলাবে। সফল হলে `{"ok":true,...}` দেখা যাবে।

এরপর Telegram-এ তোমার bot-এ `/start` পাঠাও।

## 5) Admin command
প্রজেক্ট যোগ করার ফরম্যাট:

`/add category | title | description | project URL | image URL`

Category হবে: `website`, `app`, `graphics`, `other`।

উদাহরণ:

`/add website | My Store | Ecommerce website | https://example.com | https://example.com/cover.jpg`

প্রজেক্টের তালিকা: `/projects`

প্রজেক্ট মুছতে: `/delete PROJECT_ID`

সাহায্য: `/help`

## গুরুত্বপূর্ণ নিরাপত্তা
- Bot token বা GitHub token কাউকে পাঠাবে না এবং GitHub-এ commit করবে না।
- Token শুধু Vercel Environment Variables-এ রাখবে।
- `WEBHOOK_SECRET` অন্য কাউকে দেবে না।
- Bot-এ project যোগ করার সময় image URL অবশ্যই সরাসরি image URL হতে হবে, যেমন `.jpg`, `.png` বা `.webp`।
- Vercel-এ Environment Variables বদলালে নতুন deployment করতে হবে।
