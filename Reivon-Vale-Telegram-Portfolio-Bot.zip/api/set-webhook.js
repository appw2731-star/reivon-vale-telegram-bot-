import { env } from "../lib/config.js";

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).send("Method Not Allowed");
  const secret = req.query.secret;
  if (secret !== env("WEBHOOK_SECRET")) return res.status(401).send("Unauthorized");

  const url = `${env("APP_URL")}/api/webhook`;
  const response = await fetch(`https://api.telegram.org/bot${env("BOT_TOKEN")}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url,
      secret_token: env("WEBHOOK_SECRET"),
      allowed_updates: ["message", "callback_query"]
    })
  });
  const data = await response.json();
  return res.status(data.ok ? 200 : 500).json(data);
}
