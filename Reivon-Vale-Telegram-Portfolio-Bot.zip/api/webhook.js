import { env, categories } from "../lib/config.js";
import { readProjects, writeProjects } from "../lib/github-store.js";

async function telegram(method, payload) {
  const response = await fetch(`https://api.telegram.org/bot${env("BOT_TOKEN")}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  if (!data.ok) throw new Error(data.description || "Telegram API error");
  return data.result;
}

const mainKeyboard = {
  inline_keyboard: [
    [{ text: "🌐 Websites", callback_data: "cat:website" }, { text: "📱 App Designs", callback_data: "cat:app" }],
    [{ text: "🎨 Graphics", callback_data: "cat:graphics" }, { text: "💻 Other Projects", callback_data: "cat:other" }],
    [{ text: "📞 Contact", callback_data: "contact" }]
  ]
};

function isAdmin(userId) {
  return String(userId) === String(env("ADMIN_ID"));
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

async function sendMenu(chatId) {
  await telegram("sendMessage", {
    chat_id: chatId,
    text: "<b>REIVON VALE</b>\\n<i>Digital Creative Portfolio</i>\\n\\nWelcome! Explore my websites, app designs and creative projects below.",
    parse_mode: "HTML",
    reply_markup: mainKeyboard
  });
}

async function handleMessage(message) {
  const chatId = message.chat.id;
  const userId = message.from?.id;
  const text = (message.text || "").trim();

  if (text === "/start" || text === "/menu") return sendMenu(chatId);

  if (text === "/help") {
    const adminHelp = isAdmin(userId)
      ? "\\n\\n<b>Admin commands</b>\\n/add category | title | description | project URL | image URL\\nExample:\\n/add website | My Store | Ecommerce website | https://example.com | https://example.com/cover.jpg\\n/delete PROJECT_ID\\n/projects"
      : "";
    return telegram("sendMessage", { chat_id: chatId, text: "Use the menu buttons to browse the portfolio." + adminHelp, parse_mode: "HTML" });
  }

  if (text === "/projects" && isAdmin(userId)) {
    const data = await readProjects();
    const lines = data.projects.map(p => `${p.id} — ${p.title} (${p.category})`);
    return telegram("sendMessage", { chat_id: chatId, text: lines.length ? lines.join("\\n") : "No projects added yet." });
  }

  if (text.startsWith("/add ")) {
    if (!isAdmin(userId)) return telegram("sendMessage", { chat_id: chatId, text: "⛔ Admin only." });
    const parts = text.slice(5).split("|").map(s => s.trim());
    if (parts.length !== 5) {
      return telegram("sendMessage", { chat_id: chatId, text: "Format:\\n/add category | title | description | project URL | image URL\\nCategories: website, app, graphics, other" });
    }
    const [category, title, description, url, image] = parts;
    if (!categories[category]) return telegram("sendMessage", { chat_id: chatId, text: "Invalid category. Use website, app, graphics or other." });
    if (!/^https?:\\/\\//i.test(url) || !/^https?:\\/\\//i.test(image)) {
      return telegram("sendMessage", { chat_id: chatId, text: "Project URL and image URL must start with http:// or https://." });
    }
    const data = await readProjects();
    const id = `RV${Date.now().toString().slice(-8)}`;
    data.projects.push({ id, category, title, description, url, image });
    await writeProjects(data, `Add portfolio project ${id}`);
    return telegram("sendMessage", { chat_id: chatId, text: `✅ Project added!\\nID: ${id}\\nTitle: ${escapeHtml(title)}`, parse_mode: "HTML" });
  }

  if (text.startsWith("/delete ")) {
    if (!isAdmin(userId)) return telegram("sendMessage", { chat_id: chatId, text: "⛔ Admin only." });
    const id = text.slice(8).trim();
    const data = await readProjects();
    const before = data.projects.length;
    data.projects = data.projects.filter(p => p.id !== id);
    if (data.projects.length === before) return telegram("sendMessage", { chat_id: chatId, text: "Project ID not found." });
    await writeProjects(data, `Delete portfolio project ${id}`);
    return telegram("sendMessage", { chat_id: chatId, text: "🗑 Project deleted." });
  }

  if (text.startsWith("/")) return telegram("sendMessage", { chat_id: chatId, text: "Unknown command. Send /menu to browse or /help for help." });
}

async function handleCallback(query) {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  await telegram("answerCallbackQuery", { callback_query_id: query.id });

  if (query.data === "contact") {
    return telegram("sendMessage", { chat_id: chatId, text: "📩 Contact: Add your email or social links in api/webhook.js to customize this section." });
  }

  if (query.data?.startsWith("cat:")) {
    const category = query.data.split(":")[1];
    const data = await readProjects();
    const projects = data.projects.filter(p => p.category === category);
    if (!projects.length) {
      return telegram("sendMessage", { chat_id: chatId, text: `${categories[category] || "Projects"}\\n\\nNo projects added here yet.` });
    }
    for (const p of projects.slice(0, 20)) {
      const caption = `<b>${escapeHtml(p.title)}</b>\\n\\n${escapeHtml(p.description)}\\n\\nID: <code>${escapeHtml(p.id)}</code>`;
      await telegram("sendPhoto", {
        chat_id: chatId,
        photo: p.image,
        caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "🔗 View Project", url: p.url }], [{ text: "⬅️ Main Menu", callback_data: "home" }]] }
      });
    }
    return;
  }

  if (query.data === "home") {
    return telegram("editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text: "<b>REIVON VALE</b>\\n<i>Digital Creative Portfolio</i>\\n\\nChoose a category:",
      parse_mode: "HTML",
      reply_markup: mainKeyboard
    });
  }
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).send("Method Not Allowed");
  if (req.headers["x-telegram-bot-api-secret-token"] !== env("WEBHOOK_SECRET")) {
    return res.status(401).send("Unauthorized");
  }

  try {
    const update = req.body;
    if (update.message) await handleMessage(update.message);
    if (update.callback_query) await handleCallback(update.callback_query);
    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(200).json({ ok: true });
  }
}
